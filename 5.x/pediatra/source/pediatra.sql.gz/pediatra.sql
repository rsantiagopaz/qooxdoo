-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 11-02-2017 a las 20:53:24
-- Versión del servidor: 5.1.41
-- Versión de PHP: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `pediatra`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `notaper`
--

CREATE TABLE IF NOT EXISTS `notaper` (
  `id_notaper` int(10) NOT NULL AUTO_INCREMENT,
  `descrip` varchar(50) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `texto` text COLLATE utf8_spanish2_ci,
  PRIMARY KEY (`id_notaper`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=3 ;

--
-- Volcar la base de datos para la tabla `notaper`
--

INSERT INTO `notaper` (`id_notaper`, `descrip`, `texto`) VALUES
(1, 'Primera nota de prueba', 'sdfsdfsdf sdfkj ñlksjd fñlj sdf l sdflkjh lkjhs dflkjh lkj sldkjf lkjh sldkjf lkj lsdjf lkj klj sdlkfjh lkjh sdfoiuh i sdf lkh lkjsdfh lkj lkj lksjd flkjh ljk sldfh lkjh sdfiu sodifg jkhg sdkjfh kjh kjhsd f'),
(2, 'segunda nota', 'sdfh sdkfjh lsdfj lkjh sdlfkjh lkjh sdlfkj lkjhs dlfkjh lkjh spdiuf oiu sdofuiy oi sdfy oiudy fgiou odufg oiu oiudf oiu ou dofgiuy ou oiduf gbcvjbh lkjh vbkj ,cvbn s ndsd fhoisdyfps dfkljhs dflj\r\nsdfh sdkfjh lsdfj lkjh sdlfkjh lkjh sdlfkj lkjhs dlfkjh lkjh spdiuf oiu sdofuiy oi sdfy oiudy fgiou odufg oiu oiudf oiu ou dofgiuy ou oiduf gbcvjbh lkjh vbkj ,cvbn s ndsd fhoisdyfps dfkljhs dflj\r\nsdfh sdkfjh lsdfj lkjh sdlfkjh lkjh sdlfkj lkjhs dlfkjh lkjh spdiuf oiu sdofuiy oi sdfy oiudy fgiou odufg oiu oiudf oiu ou dofgiuy ou oiduf gbcvjbh lkjh vbkj ,cvbn s ndsd fhoisdyfps dfkljhs dflj');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `paciente`
--

CREATE TABLE IF NOT EXISTS `paciente` (
  `id_paciente` int(11) NOT NULL AUTO_INCREMENT,
  `apellido` varchar(30) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `nombre` varchar(30) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `domicilio` varchar(100) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `id_localidad` int(11) DEFAULT NULL,
  `localidad` varchar(255) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `fnac` date DEFAULT NULL,
  `tipo_doc` enum('D','C') COLLATE utf8_spanish2_ci DEFAULT NULL,
  `nro_doc` varchar(30) COLLATE utf8_spanish2_ci DEFAULT NULL,
  PRIMARY KEY (`id_paciente`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=3 ;

--
-- Volcar la base de datos para la tabla `paciente`
--

INSERT INTO `paciente` (`id_paciente`, `apellido`, `nombre`, `domicilio`, `id_localidad`, `localidad`, `fnac`, `tipo_doc`, `nro_doc`) VALUES
(1, 'Paz', 'Maria Agustina', 'Andres Rojas 471', NULL, 'probando probando 1', NULL, NULL, '11111111'),
(2, 'Gelblung', 'Chiche', 'Bs As', NULL, 'probando probando 2', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `paramed`
--

CREATE TABLE IF NOT EXISTS `paramed` (
  `id_paramed` int(10) NOT NULL AUTO_INCREMENT,
  `descrip` varchar(100) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `codigo` varchar(20) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `id_tipo_paramed` int(10) DEFAULT NULL,
  PRIMARY KEY (`id_paramed`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `paramed`
--

INSERT INTO `paramed` (`id_paramed`, `descrip`, `codigo`, `id_tipo_paramed`) VALUES
(1, 'Diagno 1', NULL, 1),
(2, 'Medi 1', NULL, 2),
(3, 'Diagno 2', NULL, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `texto_predefinido`
--

CREATE TABLE IF NOT EXISTS `texto_predefinido` (
  `id_textopredefinido` int(10) NOT NULL AUTO_INCREMENT,
  `texto` varchar(100) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `orden` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id_textopredefinido`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=5 ;

--
-- Volcar la base de datos para la tabla `texto_predefinido`
--

INSERT INTO `texto_predefinido` (`id_textopredefinido`, `texto`, `orden`) VALUES
(1, 'Primer texto de prueba', 0),
(2, 'Segundo texto', 1),
(3, 'tercero', 2),
(4, 'cuarto', 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_paramed`
--

CREATE TABLE IF NOT EXISTS `tipo_paramed` (
  `id_tipo_paramed` int(10) NOT NULL AUTO_INCREMENT,
  `descrip` varchar(20) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `color` int(10) DEFAULT NULL,
  PRIMARY KEY (`id_tipo_paramed`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=3 ;

--
-- Volcar la base de datos para la tabla `tipo_paramed`
--

INSERT INTO `tipo_paramed` (`id_tipo_paramed`, `descrip`, `color`) VALUES
(1, 'Diagnóstico', NULL),
(2, 'Medicamento', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `visita`
--

CREATE TABLE IF NOT EXISTS `visita` (
  `id_visita` int(11) NOT NULL AUTO_INCREMENT,
  `id_paciente` int(11) DEFAULT NULL,
  `fecha` datetime DEFAULT NULL,
  `motivo` varchar(100) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `antecedentes` varchar(100) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `texto` varchar(500) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `per_enc` decimal(4,2) DEFAULT NULL,
  `talla` decimal(3,2) DEFAULT NULL,
  `peso` decimal(6,3) DEFAULT NULL,
  `presion` varchar(7) COLLATE utf8_spanish2_ci DEFAULT NULL,
  PRIMARY KEY (`id_visita`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `visita`
--

INSERT INTO `visita` (`id_visita`, `id_paciente`, `fecha`, `motivo`, `antecedentes`, `texto`, `per_enc`, `talla`, `peso`, `presion`) VALUES
(1, 2, '2016-11-23 00:00:00', 'motivo', 'antecedentes', 'texto', '1.11', '2.00', '3.000', '4'),
(2, 2, '2016-11-23 00:00:00', 'm2', 'a2', 't2', '11.00', '9.99', '33.000', '44'),
(3, 2, '2016-11-23 00:00:00', 'm3', 'a3', 't3', '11.00', '9.99', '33.000', '44');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `visita_paramed`
--

CREATE TABLE IF NOT EXISTS `visita_paramed` (
  `id_visita` int(11) DEFAULT NULL,
  `id_paramed` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcar la base de datos para la tabla `visita_paramed`
--


/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
