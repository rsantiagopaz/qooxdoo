-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 11-02-2017 a las 20:56:47
-- Versión del servidor: 5.1.41
-- Versión de PHP: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `inventario`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `bien`
--

CREATE TABLE IF NOT EXISTS `bien` (
  `id_bien` int(11) NOT NULL AUTO_INCREMENT,
  `descrip` varchar(50) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `nro_expediente` varchar(30) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `id_tipo_bien` int(11) DEFAULT NULL,
  `organismo_area_id` varchar(5) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `nro_serie` varchar(30) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `id_tipo_alta` int(11) DEFAULT NULL,
  `fecha_alta` date DEFAULT NULL,
  `id_oas_usuario_alta` int(11) DEFAULT NULL,
  `id_tipo_baja` int(11) DEFAULT NULL,
  `fecha_baja` date DEFAULT NULL,
  `id_oas_usuario_baja` int(11) DEFAULT NULL,
  `proveedor` varchar(50) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `nro_remito` varchar(30) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `cuit` varchar(30) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `observa_alta` varchar(100) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `observa_baja` varchar(100) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `codigo_barra` varchar(1000) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `codigo_qr` varchar(1000) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `estado` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id_bien`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `bien`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `movimiento`
--

CREATE TABLE IF NOT EXISTS `movimiento` (
  `id_movimiento` int(11) NOT NULL AUTO_INCREMENT,
  `id_bien` int(11) DEFAULT NULL,
  `tipo_movimiento` enum('A','B','P') COLLATE utf8_spanish2_ci DEFAULT NULL,
  `fecha_movimiento` date DEFAULT NULL,
  `id_organismo_area_servicio_origen` int(11) DEFAULT NULL,
  `id_organismo_area_servicio_destino` int(11) DEFAULT NULL,
  `id_oas_usuario_movimiento` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_movimiento`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `movimiento`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_alta`
--

CREATE TABLE IF NOT EXISTS `tipo_alta` (
  `id_tipo_alta` int(11) NOT NULL AUTO_INCREMENT,
  `descrip` varchar(50) COLLATE utf8_spanish2_ci DEFAULT NULL,
  PRIMARY KEY (`id_tipo_alta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `tipo_alta`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_baja`
--

CREATE TABLE IF NOT EXISTS `tipo_baja` (
  `id_tipo_baja` int(11) NOT NULL AUTO_INCREMENT,
  `descrip` varchar(50) COLLATE utf8_spanish2_ci DEFAULT NULL,
  PRIMARY KEY (`id_tipo_baja`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `tipo_baja`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_bien`
--

CREATE TABLE IF NOT EXISTS `tipo_bien` (
  `id_tipo_bien` int(11) NOT NULL AUTO_INCREMENT,
  `descrip` varchar(50) COLLATE utf8_spanish2_ci DEFAULT NULL,
  PRIMARY KEY (`id_tipo_bien`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `tipo_bien`
--


/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
